@component('mail::message')
# 夢寶石數量過低警告！

您的夢寶石數量剩餘：{{ $remain }}
@endcomponent
